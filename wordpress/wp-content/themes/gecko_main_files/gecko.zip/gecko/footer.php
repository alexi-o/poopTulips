<?php
/**
 * The template for displaying the footer.
 *
 * @since   1.0.0
 * @package Gecko
 */
?>
			<?php jas_gecko_footer(); ?>
		</div><!-- #jas-wrapper -->
		<a id="jas-backtop" class="pf br__50"><span class="tc bgp br__50 db cw"><i class="pr pe-7s-angle-up"></i></span></a>

		<?php wp_footer(); ?>
	</body>
</html>