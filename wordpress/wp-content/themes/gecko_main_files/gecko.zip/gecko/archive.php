<?php
/**
 * The template for displaying archive pages.
 *
 * @since   1.0.0
 * @package Gecko
 */

get_template_part( 'index' );